﻿ --DelicatesesMart
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Mortadela de Pavo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2500000,'Mortadela de Pollo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1500000,'Salchichas de Pollo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2500000,'Nugget de Pollo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1800000,'Salchichas de Pavo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1400000,'Nugget de Pavo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Jamon de Pavo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3200000,'Jamon de Pollo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3200000, 'Chorizo de Pollo',1000,3,1,1);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (100000, 'Jamon de Pavo',1000,3,1,1);

 --Martextil
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3200000,'Toalla Grande',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Toalla Pequeña',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (4000000,'Toalla Maquillaje',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Alfombra para baños',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3200000,'Alfombra para Entradas',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6000000,'Alfombra para Salas',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6500000,'Cojin',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6500000,'Almohada',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (9000000,'Cubre Cama',1000,4,2,2);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (9500000,'Cobija',1000,4,2,2);

 --Tecmarca
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (800000000,'Televisor Pantalla Plana 32pul',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000000,'SmarTv',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (950000000,'Televisor Pantalla Plana 40pul',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (800000000,'Corneta de Bluetooth',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000000,'Corneta estero',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (30000000,'Corneta de Blouetooth estereo',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (30000000,'Corneta Cajon Bluetooth',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (15000000,'Control remoto DirecTv',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (10000000,'Audifono Inalambrico',1000,7,3,3);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (10000000, 'Corneta 10ohms',1000,7,3,3);

 --Chocolate
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Toddy',10,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000,'Bolitas de Chocolate',25,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000,'Caramelos de Chocolate',15,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Chocolate de taza',110,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3100000,'Chocolate de Postre',110,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (100000,'Chocolate Blanco',30,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (250000,'Bombom de Chocolate',40,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (400000,'Bastone de Chocolate',50,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (300000,'Galletas Relleno de Chocolate',30,9,4,4);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (15000000,'Mani con Chocolate',100,9,4,4);

 --FishMarket
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000,'Calamar',500,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3500000,'Atun',200,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6000000,'Langosta',200,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (7000000,'Pulpo',500,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Ostras',50,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Mejillones',200,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000,'Sardinas',200,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Salmon',500,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Bacalao',200,10,5,5);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6000000,'Camarones',200,10,5,5);

 --AverMart
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Patas de Pollo y Pavo',300,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Alas de Pollo y Pavo',500,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Pechuga de Pollo y Pavo',1000,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Medallon de Pavo',200,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Pescuezo de Pollo',200,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Espinaso de Pollo y Pavo',400,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Pollo Entero',1000,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3100000,'Pavo Entero',1000,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Pollo Esmechado',500,3,6,6);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (32000000,'Pavo Esmechado',500,3,6,6);

 --Ofis
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (10000000,'Resma de Papel Tamaño Carta',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (13000000,'Resma de Papel Tamaño Oficio',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (10000000,'Engrapadora',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (1000000,'Grapas',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (8000000,'Marcadores',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (50000000,'Lapices',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (60000000,'Boligrafos',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (60000000,'Tinta de Impresora',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Libreta',10,15,7,7);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Carpeta',10,15,7,7);

 --Mueblesoft
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (90000000,'Silla Ejecutiva',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (50000000,'Silla Oficina de Sala',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (97000000,'Silla Escritorio',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (14000000,'Mesa Escritorio',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (20000000,'Silla Presidencial',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (20000000,'Estante',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (60000000,'Archivadora',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (20000000,'Lampara de Escritorio',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (20000000,'Papelera',10,16,8,8);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (100000000,'Lampara de Pared',10,16,8,8);

 --MuebleHogar
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Lampara Noche',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (140000000,'Mueble Tipo L',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (150000000,'Sofa Cama',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (130000000,'Mesa Para Comedor',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (140000000,'Juego de Mueble',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (50000000,'Puf Grande y Pequeños',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (60000000,'Mesa para Niños',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (100000000,'Perchero Ropero',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (60000000,'Silla de Plastico',10,17,9,9);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (70000000,'Silla de Plastico',10,17,9,9);

 --CarMarket
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (90000000,'Caucho r15',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (110000000,'Caucho r16',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (125000000,'Caucho r17',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (140000000,'Caucho r18',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (190000000,'Caucho r20',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Pega para Parches',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (110000000,'Gato Hidraulico',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (70000000,'Bateria de Carro',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (50000000,'Cable Auxiliar',5000,18,10,10);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (10000000,'Alfombra de Carro',5000,18,10,10);

 --IndustriasMart
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Detergente',1000,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6000000,'Cloro',500,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Jabon Liquido',500,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (2000000,'Antibacterial Liquido',250,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Antibacterial Aroma',250,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (5000000,'Desinfectante',1000,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (6000000,'Cera Neutral',500,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (4000000,'Desengrasante',500,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (3000000,'Lava platos',10,2,11,11);
INSERT INTO producto (pr_precio, pr_nombre, pr_peso, fk_rubro, fk_marca, fk_proveedor) VALUES (4000000,'Blanqueador',10,2,11,11);



INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (1,'2020-3-9','2020-3-19',50,'TRUE');
INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (10,'2020-7-15','2020-7-25',75,'TRUE');
INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (20,'2020-3-9','2020-3-19',20,'TRUE');
INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (30,'2020-7-05','2020-7-15',20,'FALSE');
INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (40,'2020-3-9','2020-3-19',30,'FALSE');
INSERT INTO descuento (fk_producto,de_fecha_ini,de_fecha_fin,de_porcentaje,de_notimart) VALUES (50,'2020-1-15','2020-1-25',50,'FALSE');