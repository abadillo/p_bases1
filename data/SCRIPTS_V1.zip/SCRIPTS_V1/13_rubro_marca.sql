﻿INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('DelicatesesMart', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Martextil', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Tecnomarca', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Chocolatieres', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('FishMarket', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('AvesMart', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Ofis', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Mueblesoft', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('MuebleHogar', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('CarMarket', 'TRUE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('IndustrialMart', 'TRUE');

INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Colgate', 'FALSE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Ariel', 'FALSE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Head & Shoulders', 'FALSE');
INSERT INTO marca (ma_nombre, ma_ucabmart) VALUES ('Primor', 'FALSE');
				


			
INSERT INTO rubro (ru_nombre) VALUES ('Higiene');
 --IndustrialMart				
INSERT INTO rubro (ru_nombre) VALUES ('Limpieza');
INSERT INTO rubro (ru_nombre) VALUES ('Alimentos');			
 --Martextil				
INSERT INTO rubro (ru_nombre) VALUES ('Lenceria');
INSERT INTO rubro (ru_nombre) VALUES ('Almohadas');
INSERT INTO rubro (ru_nombre) VALUES ('Colchones');
 --Tecnomarca				
INSERT INTO rubro (ru_nombre) VALUES ('Televisores');
INSERT INTO rubro (ru_nombre) VALUES ('Equipo de Sonido');
 --Chocolatieres				
INSERT INTO rubro (ru_nombre) VALUES ('Chocolate');
 --FishMarket				
INSERT INTO rubro (ru_nombre) VALUES ('Frutos de mar Congelados');
INSERT INTO rubro (ru_nombre) VALUES ('Empacados al Vacio');
 --AvesMart				
INSERT INTO rubro (ru_nombre) VALUES ('Pollo');
INSERT INTO rubro (ru_nombre) VALUES ('Pavo');
 --DelicatesesMart				
INSERT INTO rubro (ru_nombre) VALUES ('Embutidos');
 --Ofis				
INSERT INTO rubro (ru_nombre) VALUES ('Papeleria');
 --Mueblesoft				
INSERT INTO rubro (ru_nombre) VALUES ('Mobiliario de Oficina');
 --MuebleHogar				
INSERT INTO rubro (ru_nombre) VALUES ('Mobiliario de Hogar');
 --CarMarket				
INSERT INTO rubro (ru_nombre) VALUES ('Cauchos');



