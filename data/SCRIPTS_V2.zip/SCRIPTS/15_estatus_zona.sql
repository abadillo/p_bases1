﻿

INSERT INTO estatus_reposicion (er_nombre) VALUES ('EN REVISION');
INSERT INTO estatus_reposicion (er_nombre) VALUES ('APROBADO');
INSERT INTO estatus_reposicion (er_nombre) VALUES ('EN TRANSITO');
INSERT INTO estatus_reposicion (er_nombre) VALUES ('RECIBIDO EN TIENDA');


INSERT INTO estatus_despacho (ed_nombre) VALUES ('EN PROCESO');
INSERT INTO estatus_despacho (ed_nombre) VALUES ('LISTO PARA ENTREGA');
INSERT INTO estatus_despacho (ed_nombre) VALUES ('ENTREGADO');



INSERT INTO zona (zo_nombre) VALUES ('Refrigeración');
INSERT INTO zona (zo_nombre) VALUES ('Alimentos');
INSERT INTO zona (zo_nombre) VALUES ('Oficina y Papeleria');
INSERT INTO zona (zo_nombre) VALUES ('Electrodomesticos');
INSERT INTO zona (zo_nombre) VALUES ('Limpieza');
INSERT INTO zona (zo_nombre) VALUES ('Hogar');
INSERT INTO zona (zo_nombre) VALUES ('AutoAutopartes');