
DROP TABLE metodo_pago_compra;
DROP TABLE compra;
DROP TABLE estatus_despacho;
DROP TABLE carrito_producto;
DROP TABLE carrito;
/*CARRITO Y COMPRAS*/

DROP TABLE pasillo;
DROP TABLE almacen;
DROP TABLE zona;
DROP TABLE orden_reposicion;
DROP TABLE estatus_reposicion;
DROP TABLE descuento;
DROP TABLE producto;
DROP TABLE rubro;
DROP TABLE marca;
/*PRODUCTO , CARRITO, ORDENES*/

DROP TABLE telefono;
DROP TABLE persona_contacto;
DROP TABLE proveedor;
DROP TABLE usuario;
/*CLIENTES , PROVEEDORES, EMPLEADOS Y PERSONAS CONTACTO*/

DROP TABLE cotizacion;
DROP TABLE moneda;
DROP TABLE metodo_pago;
DROP TABLE tipo_pago;
DROP TABLE cliente;
/*CLIENTES*/

DROP TABLE vacaciones;
DROP TABLE control_entrada;
DROP TABLE beneficio_empleado;
DROP TABLE beneficio;
DROP TABLE horario_empleado;
DROP TABLE horario;
DROP TABLE empleado;
/* EMPLEADOS */

DROP TABLE privilegio_rol;
DROP TABLE privilegio;
DROP TABLE rol;
DROP TABLE tienda;
/* TIENDA Y  PRODUCTOS*/

DROP TABLE lugar;

